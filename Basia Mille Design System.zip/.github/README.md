# Basia Mille Design System

Editorial fashion design system with glassmorphism UI — warm neutrals, condensed serifs, LOLO-inspired bento cards.

## Installation

1. Clone this repository
2. Open `ui_kits/storefront/index.html` in a browser
3. All fonts are loaded from Google Fonts CDN

## Structure

```
├── colors_and_type.css       # Core design tokens
├── assets/                    # Logo SVGs
├── preview/                   # Component preview cards
└── ui_kits/
    └── storefront/            # Shopify collection page UI kit
```

## Features

- **Neutral-first palette:** Warm beige canvas, ivory paper, pink-soft accents
- **Glassmorphism:** Frosted glass cards with backdrop blur, vignette overlays, reflections
- **Typography:** Playfair Display condensed serifs + Inter sans + JetBrains Mono
- **Components:** Product cards, navigation pills, buttons, forms, filters

## Documentation

See [README.md](./README.md) for full design system documentation.

## License

© 2026 U See Studio LLC
