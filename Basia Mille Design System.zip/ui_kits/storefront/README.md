# Storefront UI kit — Basia Mille

A single-page click-thru of a **Shopify Collection page** (Mael Femme brand), showing how the editorial identity translates into merchandising.

## Components covered

- Announcement banner
- Sticky nav with wordmark, uppercase menu, cart indicator
- Collection hero — big serif headline, italic intro, spec stats, editorial photo
- Filter chip bar + sort + count (sticky under nav)
- Product card — indexed, flagged (New / Sale), with magazine-style spec meta footer
- Editorial break row — wine-dark insert with display quote + side photo pair
- Footer — wordmark, link columns, newsletter inline

## Not yet built

- Home page
- Product detail page (PDP)
- Cart / mini-cart
- Brand index / landing
- Account
- Checkout

Ask to extend.
