# Basia Mille — Design System

Editorial fashion design system inspired by **LOLO Agency** (Monteleone, STRATEGY projects) — warm minimalism, glassmorphic cards, condensed serifs, and a neutral-first palette with soft pink accents.

---

## 🎨 Color Philosophy

**Neutral-first system:** warm beige canvas + ivory paper cards + dark brown ink. Pink-soft and green-yellow provide gentle accent surfaces. No red or high-saturation colors — the brand speaks through typography, glass effects, and restrained warmth.

### Canvas (Page Background)
- **Canvas** `#E8E6DF` — primary warm grey-beige background
- **Canvas-deep** `#D8D5CC` — pressed / outer edge tone
- **Canvas-soft** `#EFEDE6` — lifted quiet panel

### Paper & Ivory (Neutral Cards)
- **Paper** `#F5F2EA` — neutral card surface atop canvas
- **Paper-2** `#EDEAE0` — sunken subtle panel
- **Ivory** `#FAF7EE` — lightest card background

### Ink (Typography)
- **Ink** `#1A0F0B` — headline & body (warm near-black)
- **Ink-2** `#3A2018` — secondary ink, italic accents
- **Ink-3** `#7A4E3C` — tertiary metadata labels
- **Ink-4** `#B79580` — quietest text, disabled states

### Accent Cards
- **Pink-soft** `#F2DDD3` — primary accent surface (NEW — softer than card-pink)
- **Card-pink** `#E8C4B8` — secondary pink accent
- **Card-green** `#E8EDD0` — pale green-yellow tertiary accent
- **Ochre** `#B8873A` — mustard for spec tags (use sparingly)
- **Sage** `#6B7A55` — deep olive tertiary (use sparingly)

---

## 🔤 Typography

### Families
- **Display:** Playfair Display (condensed serif, editorial headlines)
- **Sans:** Inter (modern humanist sans, UI + body)
- **Mono:** JetBrains Mono (spec labels, metadata, contrast values)

### Scale
- **Hero:** 64–160px (magazine cover)
- **Display:** 48–112px (page H1)
- **H1:** 40–72px
- **H2:** 28–48px
- **H3:** 24px
- **Body-lg:** 17px
- **Body:** 15px (default)
- **Body-sm:** 13px
- **Meta:** 11px (SMALL CAPS SPEC LABELS)
- **Micro:** 10px

### Key Treatments
- **Condensed display serif:** Playfair Display, weight 300–500, font-stretch 75%, tight tracking (-0.04em to -0.06em)
- **Italic accents:** Use `font-style: italic; color: var(--ink-2)` for emphasis (e.g., "Basia**Mille**")
- **Small-caps labels:** Inter, 10–11px, weight 600, letter-spacing 0.14em, uppercase

---

## 🪟 Glassmorphism (Apple Vision Pro Style)

Signature treatment for cards, nav, buttons, and modals:

```css
background: rgba(242, 221, 211, 0.7);  /* semi-transparent pink-soft */
backdrop-filter: blur(20px) saturate(1.2);
-webkit-backdrop-filter: blur(20px) saturate(1.2);
border: 1px solid rgba(212, 130, 106, 0.4);
box-shadow: 0 8px 32px rgba(26, 15, 11, 0.1), inset 0 1px 0 rgba(255, 255, 255, 0.2);
border-radius: 16px;
overflow: hidden;
```

### Vignette Overlay (Edge Darkening)
Add a pseudo-element to create soft edge shadows:

```css
.card::after {
  content: '';
  position: absolute;
  inset: 0;
  border-radius: 16px;
  background: radial-gradient(ellipse at center, transparent 35%, rgba(160, 55, 30, 0.18) 100%);
  pointer-events: none;
  z-index: 1;
}
```

### Glass Reflection
Top-down light shimmer:

```css
.card::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  height: 40%;
  background: linear-gradient(180deg, rgba(255, 255, 255, 0.15) 0%, transparent 100%);
  border-radius: 16px 16px 0 0;
  pointer-events: none;
  z-index: 2;
}
```

---

## 🧩 Components

### Buttons
- **Primary:** Pink-soft glass pill, 13px uppercase sans, backdrop blur
- **Ink:** Solid dark brown, white text, minimal shadow
- **Ivory:** Light glass pill, subtle border + inset highlight
- **Ghost:** Transparent with border, hover → light fill

### Pills & Chips
- Rail background: `rgba(245, 242, 234, 0.7)` with blur(10px)
- Active state: ivory with inset highlight + subtle border
- Accent state: pink-soft with border

### Product Cards
- Pink-soft glass base (0.7 opacity)
- Vignette overlay (darker edges)
- Top reflection gradient
- Cream badges (idx, flags) at z-index: 4
- Dark brown text (#2C1810) for readability

### Navigation
- Glass rail: `rgba(245, 242, 234, 0.7)` + blur(12px)
- Monogram mark: dark circle with ivory letter
- Active pill: ivory with inset highlight

---

## 📐 Spacing & Layout

**Base unit:** 4px

- `--s-1: 4px`
- `--s-2: 8px`
- `--s-3: 12px`
- `--s-4: 16px`
- `--s-5: 24px`
- `--s-6: 32px`
- `--s-7: 48px`
- `--s-8: 64px`
- `--s-9: 96px`

**Border radius:**
- Pills/buttons: `999px`
- Cards: `16px`
- Small elements: `10px`

---

## 🎯 Usage Guidelines

### When to Use Each Color

**Canvas beige (#E8E6DF):**
- Page backgrounds
- Large section fills
- Behind glass nav/filters

**Ivory (#FAF7EE):**
- Primary card surfaces
- Button active states
- Input backgrounds

**Pink-soft (#F2DDD3):**
- **Primary accent cards** (product cards, CTA surfaces)
- Cart/sale pills
- Highlight backgrounds

**Card-pink (#E8C4B8) / Card-green (#E8EDD0):**
- Secondary/tertiary accent cards
- Editorial breaks
- Alternating section backgrounds

**Ink tones:**
- Ink (#1A0F0B): headlines, body text, dark buttons
- Ink-2 (#3A2018): italic accents, secondary text
- Ink-3 (#7A4E3C): metadata, labels
- Ink-4 (#B79580): disabled states

### Typography Best Practices

1. **Condensed serifs for drama:** Use Playfair Display at weight 300–500, font-stretch 75%, with tight tracking for oversized headlines
2. **Italic for emphasis:** Apply `font-style: italic; color: var(--ink-2)` to key words in display type
3. **Small-caps for metadata:** 10–11px Inter, weight 600, uppercase, letter-spacing 0.14em
4. **Body text:** 15px Inter, line-height 1.55, no letter-spacing

### Glassmorphism Tips

- **Blur intensity:** 10–20px for small elements (chips, buttons), 20–24px for large cards
- **Saturation boost:** Add `saturate(1.2)` to backdrop-filter for richer color
- **Vignette strength:** Start fade at 35–50% center, end at 100% with 0.15–0.22 opacity
- **Layering:** Content z-index: 3, vignette z-index: 1, reflection z-index: 2, badges z-index: 4

---

## 🔗 Inspiration Sources

- **LOLO Agency:** Monteleone bento cards (pink vignette backgrounds), STRATEGY typography (condensed serif all-caps)
- **Apple Vision Pro:** Glassmorphism UI (frosted glass, subtle reflections, depth layering)
- **Editorial fashion:** Warm neutrals, restrained color, type-first layouts

---

## 📦 Files

- `colors_and_type.css` — All tokens (colors, type scale, spacing)
- `ui_kits/storefront/` — Shopify collection page UI kit (glassmorphic product cards, nav, filters, footer)
- `preview/` — Component preview cards for design system tab
- `assets/` — Logo SVGs (wordmark + monogram)

---

## ✨ What Makes This System Unique

1. **Neutral-first palette:** No red, no high-saturation colors — warmth through beige/pink/brown earth tones
2. **Glassmorphism everywhere:** Semi-transparent surfaces with backdrop blur, vignette overlays, and top reflections
3. **Typography-driven hierarchy:** Condensed display serifs, tight tracking, italic accents in ink-2
4. **LOLO-inspired bento cards:** Pink-soft backgrounds with radial gradient vignettes (darker edges, lighter center)
5. **Apple Vision Pro depth:** Layered pseudo-elements, inset highlights, soft shadows

---

**Last updated:** April 30, 2026  
**Project:** Basia Mille Design System  
**Designer:** U See Studio LLC
